// TOPIC: Assignment Operator Overloading in C++.
//
// POINTS:
// 0. When should we write our own assignment operator in C++?
// 1. This comes under binary operator overloading.
// 2. When we need deep copy, assignment operator mush be overloaded.
// 3. We should also create own copy constructor when overloading assignment operator
//    and vice versa.
//
// FUNCTION POINTS:
// 0. Check self assignment because it is dangerous (we will discussed).
// 1. Assignment operator must be overloaded nu a non-static member function only.

#include <iostream>
using namespace std;
class Base {
    int x;
public:
    Base(int x = 0): x {x} {}
    friend class Test;
};
class Test {
    int *x;
public:
    Test(int val = 0): x{new int (val)} {
        cout << "Initializer: " << endl;
        cout << "*x = " << *x << endl;
    }
    void setX(int val) {
        cout << "setX: " << endl;
        *x = val;
    }
    void print() {
        cout << "OUTPUT: " << *x << endl;
    }
    ~Test() {
        cout << "Destructor: ~Test()" << endl;
        delete x;
    }
    Test & operator = (const Test & rhs) {
        if (this != &rhs)
            *x = *rhs.x;
        else *this;
    }
    Test & operator = (const Base & rhs) {
        //if (this != &rhs)
        *x = rhs.x;
        return *this;
    }
};
int main() {
    cout << "Test t1 (10): " << endl;
    Test t1 (10);
    cout << endl;
    cout << "Base b(20): " << endl;
    Base b(20);
    cout << endl;
    cout << "t1 = b: " << endl;
    t1 = b;
    cout << endl;
    t1.print();
    return 0;
}
