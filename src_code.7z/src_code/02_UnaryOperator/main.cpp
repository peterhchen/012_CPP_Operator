// TOPIC: Unary Operator Overloading in C++.
// POINTS:
// 0. Operator overloading works with (class/struct).
// 1. Unary operator overloading needs only on operand.
#include <iostream>
using namespace std;
class Point {
    int x;
    int y;
public:
    Point(int x = 0, int y = 0): x {x}, y{y} {
        cout << "Initialized constructor called:" << endl;
    }
    void print () {
        cout << "x: " << x << " y: " << y << endl;
    }
    Point operator - () {
        cout << "operator - called: " << endl;
        return Point(-x, -y);
    }
};
int main() {
    cout << "main => Point p1(1, 2);" << endl;
    Point p1(1, 2);
    p1.print();
    cout << "main => Point p2;" << endl;
    Point p2;
    p2.print();
    cout << "main => p3 = -p1;" << endl;
    Point p3 = -p1;
    p3.print();
    return 0;
}
