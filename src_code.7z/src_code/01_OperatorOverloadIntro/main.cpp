// TOPIC:
// Operator Overloading In C++
//
// NOTES:
// 1. In C++, it is possible to change the behavior of operators. (+, -, *, ...)
// 2. But we can change the behavior for user defined types (class, struct) only.
//
// POINTS
// 1. if we use them (+,-, *, /, operator overload), our program becomes more intuitive.

// Thre are few operators we cannot overlaod.
// A. ::
// B. ?:
// C. .
// D. .*
// E. sizeof
// F. typid

#include <iostream>
using namespace std;
class Point {
    int x;
    int y;
public:
    Point(int x =0, int y = 0): x{x}, y{y} {}
    // rhs: right-hand-side object
    Point operator + (const Point & rhs) {
        Point p;
        p.x = x + rhs.x;
        p.y = y + rhs.y;
        return p;
    }
    Point operator - (const Point & rhs) {
        Point p;
        p.x = x - rhs.x;
        p.y = y - rhs.y;
        return p;
    }
    void print() {
        cout << "x: " << x  << " y: " << y << endl;
    }
};
int main() {
    int a = 10, b = 20;
    int c = a + b;
    cout << "c = " << c << endl;

    Point p1(1, 2), p2(3, 4);
    cout << "p1.print(): " << endl;
    p1.print();
    cout << "p2.print(): " << endl;
    p2.print();
    Point p3 = p1 + p2;
    // Point p3 = p1.operator::+(p2);
    cout << "p3.print(): " << endl;
    p3.print();
    Point p5 = p1 - p2;
    cout << "p5.print(): " << endl;
    p5.print();

    return 0;
}
